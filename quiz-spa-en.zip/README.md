# Quiz System (English-only, No Timer)

Single-file quiz built with HTML/CSS/JS.

- Open `index.html` in a browser (phone/PC).
- GitHub Pages: Settings → Pages → Deploy from a branch (main, /(root)).
